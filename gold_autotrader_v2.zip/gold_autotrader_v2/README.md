# Gold AutoTrader v2 — mobile web dashboard (paper-only)

This is a **working Streamlit research web application**, not a live brokerage bot. No broker connection, real-money order submission, continuous hosting, or proven trading edge is included.

## Run locally

Python 3.10+:

```bash
pip install -r requirements.txt
streamlit run app.py
```

Open the URL printed by Streamlit on a phone connected to the same network (your firewall must permit access). For internet access from anywhere, deploy the repository to a Streamlit-compatible hosting provider; configure authentication and protect uploaded data before exposing it publicly. Hosting and credentials are not included.

## Use

1. Download historical prices from Yahoo for research, or upload a CSV with `Date,Close` and at least 220 trading days. **Verify the quote currency and unit**; London listings may quote GBp rather than GBP. Convert GBp to GBP before upload if applicable.
2. Choose Cautious, Balanced or Active and set fixed commissions and spread/slippage assumptions.
3. Run the historical backtest; compare the strategy to buy-and-hold and inspect trades.
4. The signal preview is *not* a placed order. No live data subscription or background process is started by the website.

## Design

- Daily 50/200 SMA, price above 200 SMA, positive 63-day momentum.
- Prior-session signal used for next-session close fill approximation; no future price leakage from the signal.
- Long-only; fractional shares assumed (many brokers do not support fractional ETCs).
- 25% default position size, 5% default portfolio drawdown halt; neither is a guaranteed maximum loss.
- Conservative cost assumptions are user-editable, including a fixed fee.
- £100 initial account, no leverage.
- All results are historical simulations. No trained AI, no validated forecast probabilities.

## What's needed for safe unattended paper trading

- A licensed, reliable data feed with confirmed GBP pricing and freshness checks.
- A server-side scheduler, durable database, per-account identity and audit log.
- Idempotent order processing, exchange calendars, alerts, monitoring and a kill switch.
- Walk-forward testing, out-of-sample evaluation and forward paper trading.

## Future live trading (not implemented)

Broker API availability, fees, minimum order sizes, fractional ETC support, authentication, regulatory requirements, account reconciliation, max notional limits, stale-price rejection and explicit opt-in must all be verified before implementing any live adapter. With £100, fixed trading fees can overwhelm expected returns.
